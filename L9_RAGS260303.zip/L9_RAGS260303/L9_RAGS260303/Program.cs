﻿using System;

namespace L9_RAGS260303
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el radio: ");
            Circulo circulo = new Circulo();
            circulo.radio = int.Parse(Console.ReadLine());

            double perimetro = 0.0, area = 0.0, volumen = 0.0;

            circulo.CalcularGeometria(ref perimetro, ref area, ref volumen);

            Console.WriteLine("Perimetro del Circulo: " + perimetro);
            Console.WriteLine("Area del Circulo: " + area);
            Console.WriteLine("Volumen del Circulo: " + volumen);
        }
    }
}
